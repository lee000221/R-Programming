#section 2, question1
isFactor <- function(matric_number) {
  last_three_digits <- as.integer(substring(matric_number, nchar(matric_number) - 2))
  #print(last_three_digits)
  return(last_three_digits %% 4 == 0)
}
isFactor ("22061463")

isFactor ("s2164604")

isFactor ("17153072")

#question 2
library(ggplot2)
library(dplyr)
library(grid)

data <- read.csv("ocean.csv", header = FALSE)

colnames(data) <- c("buoy_id", "latitude", "longitude", "air_temperature", "water_temperature")

mean(data$water_temperature, na.rm = TRUE)
average_temp <- round(average_temp, 2)

data <- data %>%
  mutate(
    temp_status = case_when(
      is.na(water_temperature) ~ "N",  # Null Island
      water_temperature > average_temp ~ "H",  # Higher than average
      water_temperature < average_temp ~ "C",  # Lower than average
      TRUE ~ "A"  # Same as average
    )
  )
#(should use matrix)
heatmap <- ggplot(data, aes(x = longitude, y = latitude)) +
  geom_text(aes(label = ifelse(water_temperature > mean(water_temperature, na.rm = TRUE), "H", "C")),
            color = "grey", size = 2) +
  labs(title = paste("Average Temperature ", average_temp),
       x = "Longitude",
       y = "Latitude") +
  theme_bw() +
  theme(plot.margin = margin(1, 1, 1, 1, "cm"))
final_heatmap <- heatmap + coord_cartesian(xlim = c(-10, 10), ylim = c(-10, 10))
print(final_heatmap)
