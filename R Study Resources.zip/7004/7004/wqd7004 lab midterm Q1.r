P <- 10000
i <- 4
 # calculate simple monthly rate
   monthly_rate = i / 100 / 12
 # calculate (constant) contractual monthly payment amount
   #       derived from the present value formula for annuities
   r = (1 + monthly_rate) ^ 12 - 1
monthly_payment = round((P * monthly_rate * ((r + 1) / r)),digits=1)
payment_months = 12

# initialize output variables
 interest = principal = unpaid_balance = total_interest = vector("numeric", payment_months)
# calc amortization schedule
 outstanding_principal = 10000
   
 for (i in 1:payment_months) {
     intr = outstanding_principal * monthly_rate # interest to be paid
     prnp = monthly_payment - intr  # principal to be paid
     outstanding_principal = outstanding_principal - prnp # principal left
     total_intr = P - prnp
     
       interest[i]  = round(intr, digits=2)
       principal[i] = round(prnp, digits=2)
       unpaid_balance[i] = round(outstanding_principal, digits=2)
       total_interest[i] = round(total_intr, digits=2)
       
    }
knitr::kable(data.frame(month = 1:payment_months, monthly_payment, principal, interest, unpaid_balance, total_interest),
                          caption = "Payment schedule for first 12 months")

