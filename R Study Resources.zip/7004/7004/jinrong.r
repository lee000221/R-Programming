#---
#Matric Number: "S2111224"
#author: "Jinrong Zhang"
#date: '2022-05-28'
#output: html_document

#Question1
Principal<-list()
Unpaid_Balance<-list()
Interest<-list()
Total_Interest<-list()
i<-4 #i equals to yearly interest rate in %
n<-1
P<-11224 #the last five number of matric number
Interest_In_Total<-0
for (n in c(1:12)) {
   M<-round((P*i/(12*100))/(1-1/(1+i/(12*100))^12),2)#compute the Monthly payment
   C<-M*(1/(1+i/(12*100))^(1+12-n))# compute the Principal portion due
   I<-round(M-C,2)#compute the interest per month
   L<-round(M-I,2)#compute the Principal
   R<-round(I/(i/(12*100))-C,2)#compute the unpaid balance
   Interest_In_Total<-round(Interest_In_Total,2)+I
   Interest[[n]]<-I
   Unpaid_Balance[[n]]<-R
   Principal[[n]]<-L
   Total_Interest[[n]]<-Interest_In_Total
   n<-n+1
}
unlist(Principal)
unlist(Unpaid_Balance)
unlist(Interest)
unlist(Total_Interest)

Month<-c(1:12)
Monthly_Payment<-rep(M,time=12)
df1<-cbind(c(1:12),Month,Monthly_Payment,Principal,Interest,Unpaid_Balance,Total_Interest)
print(df1)



#Questtion2
checkString = function(word){
  num_sum =0
  a_sum =0
  
  for (i in 1:nchar(word)){
    a = substring(word,i,i)
    code <- strtoi(charToRaw(a), base=16L)
    if((code >= 97 && code <= 122) || (code >= 65 && code <= 90) ){
      a_sum = 1 +a_sum
    }
    if(code >= 48 && code <= 57){
      num_sum = 1 + num_sum
    }
    
  }
  s  = strsplit(word,':')[[1]][2]
  
  
  res1 = paste("The argument is ",word)
  res2 = paste("The number of letters are ",a_sum)
  res3 = paste("The number of digits are ",num_sum)
  print(res1)
  print(res2)
  print(res3)
}
checkString("Matric : S2111224")

