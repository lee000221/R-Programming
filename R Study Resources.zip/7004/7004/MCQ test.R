
x <- 123.456
y <- "A"
n <- 1:18

sprintf("%4c", y)

a<-seq(from=2.3, to=6, by=1)
a
a<-c(2.3:5.3, 1)
a
a<--1*seq(from=-2.3, to=-6, by=-1)
a
a<-c(2.3:5.3)
a

x<-sample(50,10,replace=FALSE)+ 5
x

num 1=c(2.3:5.3)
num.1=c(2.3:5.3)
num_1=c(2.3:5.3)
1num=c(2.3:5.3)

y<-c(4,TRUE)
y
class(y)

X<-c(30L, 42, TRUE)
X
class(X)



x<-data.frame(num=5:8, bar=c("a","b","c","d"))
row.names(x)

v<-list(bob = c(2,3,5), john = c("aa","bb","cc","dd"), mike=c(TRUE, FALSE))
v$mike
v[3]
v[[3]]
v["mike"]

m<-matrix(c(12:1), nrow = 3, ncol = 4)
m[2,1]
m[3,4]
m[3,2]
m[2,3]
x<-c(1,2,3) 
y<-c(7,8,9)
rbind(x,y)

# Creating a data frame
df <- data.frame(
  Name = c("Alice", "Bob", "Charlie"),
  Age = c(25, 30, 35),
  stringsAsFactors = FALSE
)
colnames(df)
# Printing the data frame
print(df)
length(df)
ncol(df)
nrow(df)

# Creating a matrix
mat <- matrix(
  c(1, 2.2, "a", 4, 5, 6),
  nrow = 2,
  ncol = 3,
  byrow = TRUE
)

# Printing the matrix
print(mat)
class(mat)


m<-matrix(rep(12:5,time=2), nrow = 3,ncol = 4,byrow=T)
m[1,2]
m[1,4]
m[3,2]
m[2,1]
m

# Creating a list
my_list <- list(
  Name = "Alice",
  Age = 25,
  City = "New York",
  Married = TRUE
)

# Printing the list
print(my_list)


library(ggplot2)

# Create an empty data frame with all possible combinations of latitude and longitude
data <- expand.grid(latitude = -10:10, longitude = -10:10)

# Create the empty heat map
ggplot(data, aes(x = longitude, y = latitude)) +
  geom_blank() +
  labs(title = "Empty Heat Map",
       x = "Longitude",
       y = "Latitude") +
  theme_bw() +
  theme(plot.margin = margin(1, 1, 1, 1, "cm"))
