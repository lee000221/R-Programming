#lec 4
#Selection
result<-55
if(result<65) {
  print("You did not pass")
  print("Try harder next time")
} else { 
  print("You pass")    
}

a<-20
b<-20
if(a>b) {
  print(paste(a,"is greater than",b)) 
} else if(b>a) {
  print(paste(b,"is greater than",a)) 
} else {
  print(paste(a,"is equal to",b)) 
}
# ifelse(logical_expression, x, y)
output<-ifelse(a>b, paste(a,"is greater than",b), ifelse(b>a, paste(b,"is greater than",a), paste(a,"is equal to",b))) 
print(output)

#data frame (selection)
df1<-data.frame(
  team=c("A", "A", "B", "B", "B", "C", "D"), 
  points=c(4,7,8,8,8,9,12),
  rebounds=c(3,3,4,4,6,7,7)
)
df1$columntest<-ifelse(df1$team=="A", "Great", "Bad")
# new column named status
# points greater than 7 and 
# rebounds is even number "Grade A" else "Grade B"
df1$status <- ifelse(df1$points>7 & df1$rebounds%%2==0, "Grade A", "Grade B")

#switch
switch("text-align", "margin-left" = "5px", "margin-right" = "5px", "text-align" = "right")
switch("text", "margin-left" = "5px", "margin-right" = "5px", "text-align" = "right")
switch("text", "margin-left" = "5px", "margin-right" = "5px", "text-align" = "right", "unknown")

switch(2,"red","green","blue")
switch(4,"red","green","blue")






