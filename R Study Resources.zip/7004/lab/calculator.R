# Read input from user
print(paste("Enter two numbers seprated by a space:"))
nums <- readLines("stdin",1)
print(paste("Enter the operator (+, -, x, /):"))
op <- readLines("stdin",1)

# Convert input to numeric values
nums <- strsplit(nums, " ")[[1]]
num1 <- as.numeric(nums[1])
num2 <- as.numeric(nums[2])

# Perform calculation based on operator
if(op == "+") {
  result <- num1 + num2
  op_str <- "+"
} else if(op == "-") {
  result <- num1 - num2
  op_str <- "-"
} else if(op == "x") {
  result <- num1 * num2
  op_str <- "x"
} else if(op == "/") {
  result <- num1 / num2
  op_str <- "/"
} else {
  stop("Invalid operator entered.")
}

# Print result
cat(num1, op_str, num2, "=", result)
