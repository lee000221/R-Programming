#1 create the list
my_list <- list(g1=1:10, g2="R Programming", g3="HTML")
# count the number of objects in the list
length(my_list)
# get the length of the first two vectors of the list
length(my_list$g1)
length(my_list$g2)

#2 create the lists
list1 <- c("x", "y", "z")
list2 <- c("x", "y", "z", "X", "Y", "Z")
# find the elements of list1 that are not in list2
setdiff(list2, list1)

#3 create the list
my_list <- list("G022", "G003", "G013", "G007", "G012")
# display the number of items in the list
length(my_list)
# display the second element in the list
my_list[[2]]
# add a new item to the list
my_list <- c(my_list, "G018")
# display the updated list in ascending order
my_list_sorted <- my_list[order(as.numeric(gsub("[^0-9]", "", my_list)))]
sort(unlist(my_list))

#4 create four vectors with 3 integers
a <- c(1L, 2L, 3L)
b <- c(4L, 5L, 6L)
c <- c(7L, 8L, 9L)
d <- c(10L, 11L, 12L)
# combine the vectors into a 4x3 matrix
my_matrix <- rbind(a, b, c, d)
my_matrix
# add a vector with a sequence of numbers from 1 to 4 to the matrix by row
n_row <- 1:4
new_matrix <- t(my_matrix)
my_matrix_with_seq <- rbind(new_matrix, n_row)
my_matrix_with_seq

#5 create matrix A & B
A <- matrix(c(sample(1:12,12)), nrow=3, ncol=4)
B <- matrix(c(sample(1:12,12)), nrow=4, ncol=3)
# multiply matrix A and matrix B
AB <- A %*% B
# get the dimensions of the resulting matrix
dim(AB)
AB
#ANS
matA<-matrix(sample.int(99,12),3,4)
matB<-matrix(sample.int(99,12),3,4)
print(matA)
print(matB)
# transpose mat B first to conform dimension
matM = matA %*% t(matB)
print(matM)

#6 create a matrix with 10 rows and 2 columns
m <- matrix(sample(1:20), nrow = 10, ncol = 2)
m
# extract the sub-matrix with the last 5 rows
m[6:10, ]
tail(m,5)

#7 generate a 2x2 matrix A
A <- matrix(c(2, 4, 2, 2), nrow = 2)
A
# compute the inverse of A
B <- solve(A)
B
# verify AB = BA = I
cat("AB:\n")
A %*% B
cat("BA:\n")
B %*% A

#8 With regards to the mtcars dataset
mtcars
#retrieve the number of columns
ncol(mtcars)
#retrieve the number of rows
nrow(mtcars)
#retrieve data value from row 3 and column 5
mtcars[3, 5]
#retrieve data value from row 3 and column 5 using the names
mtcars[3, "drat"]
#retrieve data of a row (Volvo 142E)
mtcars["Volvo 142E", ]
#retrieve data of column mpg
mtcars$mpg
mtcars[,"mpg"]
#retrieve data of column hp and qsec
mtcars[, c("hp", "qsec")]

#9 Create a data frame using the data
df <- data.frame(ProductCode = c("SK020", "SK042", "SK013", "SK066", "SK079"),
                 ProductName = c("Enfagrow A+", "Ayamas Nugget Crispy", "100 Plus", "Ali Cafe", "Dettol Natural"),
                 Price = c(36.79, 9.99, 6.49, 8.99, 4.99))
# View the data frame
View(df)
# Display the information above in a table sort by product name in ascending order
View(df[order(df$ProductName), ])
# Add a new row to the data frame
df <- rbind(df, data.frame(ProductCode = "SK023", ProductName = "Johnson PH", Price = 5.99))
View(df[order(df$ProductName), ])
# Display all rows where product price more than 8.00
df[df$Price > 8.00, ]
df[which(df$Price > 8.00), ]
# Display the product with maximum price and minimum price
cat("Maximum:", df$ProductName[which.max(df$Price)], "\n")
cat("Minimum:", df$ProductName[which.min(df$Price)], "\n")
# Count the number of items where the product name begins with "A"
sum(grepl("^A", df$ProductName))
sum(startsWith(df$ProductName,"A"))

