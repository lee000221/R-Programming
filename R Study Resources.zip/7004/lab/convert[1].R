#Create an R file named convert.r that used to convert inch to centimeters. Given 1 inch equals to 2.54 centimeters. 
#Display the value of centimeters in two decimal places. Run the r file using terminal. Example output:
# Read the length in inches from the user
length_in_inches <- readline(prompt="Enter the length in inches: ")

# Convert inches to centimeters
length_in_cm <- as.numeric(length_in_inches) * 2.54

# Display the result in two decimal places
cat(sprintf("The length in centimeters is %.2f", length_in_cm))
