cat("Enter the two number:")
num1 <- as.integer(readLines("stdin",1))
num2 <- as.integer(readLines("stdin",1))
total <- num1 + num2
cat(num1, "+", num2, "=", total)
