# Get input from user
print(paste("Enter M and N: "))
MN <- readLines("stdin",1)
MN <- strsplit(MN, " ")[[1]]
M <- as.numeric(MN[1])
N <- as.numeric(MN[2])
# Create matrix with random numbers
mat <- matrix(sample(1:50, M*N, replace = TRUE), nrow = M)

# Display matrix
print(mat)

# Count even and odd numbers
num_odd <- sum(mat %% 2 == 1)
num_even <- sum(mat %% 2 == 0)

# Display result
cat("Number of the odd numbers in the matrix is", num_odd, "\n")
cat("Number of the even numbers in the matrix is", num_even, "\n")
