#1. In each case, what is the value of x
x<-2-1*2 # 0
x<-6/3-2+1*0+3/3-3 #-2
x<-19%%17%%13 # 2
x<-(19%%17)%%13 #2
x<-19%%(17%%13) #3
x<-2^17%%17 #2
x<-3-2%%5+3*2-4/2 #5

#2. Shorten the notation of following vectors
#x<-c(157, 158, 159, 160, 161, 162, 163, 164)
x=157:164
#x<-c(10, 9, 8, 7, 6, 5, 4, 3, 2, 1)
x=10:1
#x<-c(-1071, -1072, -1073, -1074, -1075, -1074, -1073, -1072, -1071)
x=c(-1071:-1075, -1074:-1071)
#x<-c(1.5, 2.5, 3.5, 4.5, 5.5)
x=seq(1.5, 5.5, by = 1)
y=1.5:5.5

#3. Create a vector x of with the following value (0.15, 1.30, 3.45, 5.75). Then display the vector in character and integer.
x <- c(0.15, 1.30, 3.45, 5.75)
y <- cat("Character:",as.character(x))
z <- cat("Integer:",as.integer(x))

#4. Create a vector y based on the requirements below:
#a. A sequence of 10 numbers from 20-11
y_a=20:11
#b. A sequence of odd numbers from 11-20
y_b=seq(11, 20, by = 2)
#c. A sequence of first twelve square number starting from 1.
y_c=(1:12)^2
#d. A sequence of first eleven exponential number of 2 starting from 1.
y_d=2^(0:10)

cat("y_a: ", y_a, "\n")
cat("y_b: ", y_b, "\n")
cat("y_c: ", y_c, "\n")
cat("y_d: ", y_d, "\n")

#5. Create a vector z based on the requirements below:
#a. A sequence of 10 W
z_a1 <- gl(1,10,labels = ("W"))
z_a2 <- rep("W", 10)
#b. A sequence of R R R S S S
z_b <- rep(c("R", "S"), each = 3)
#c. The first 5 alphabets in lower case
z_c <- letters[1:5]
#d. A sequence of players from Player1 – Player10
z_d <- paste0("Player", 1:10)

cat("z_a: ", z_a1, "\n")
cat("z_b: ", z_b, "\n")
cat("z_c: ", z_c, "\n")
cat("z_d: ", z_d, "\n")

#6.a. Display the vector
name <- c("Ali", "Abu", "Ahmad", "Bala", "Chong")
Mtut1 <- c(15, 17, 10, 8, 19)
Mtut2 <- c(5, 4, 3, 5, 4)
names(Mtut1) <- name
names(Mtut2) <- name
Mtut1
Mtut2
#b. What is the total mark for Abu?
total <- Mtut1["Abu"]+Mtut2["Abu"]
total
#c. Display the percentage for each student in two decimal places if the total mark is 30.
print(format(round(Mtut1+Mtut2)/30,2),nsmall=2)
#7. Create a vector num of size 10 with any random value from 51-100. Display the vector and then assign all the even numbers to a new vector named even.
# create a vector of 10 random numbers between 51 and 100
num <- sample(51:100, 10)
num
# create a new vector with only even numbers
even <- num[num %% 2 == 0]
even

