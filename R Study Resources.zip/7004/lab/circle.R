# Read input from user
print(paste("Enter radius of a circle: "))
radius <- readLines("stdin",1)
print(paste("Enter coordinate x and y separated by a space: "))
coords <- readLines("stdin",1)

# Convert input to numeric values
radius <- as.numeric(radius)
coords <- strsplit(coords, " ")[[1]]
x <- as.numeric(coords[1])
y <- as.numeric(coords[2])

# Calculate distance from point to center of circle
distance <- sqrt(x^2 + y^2)

# Determine if point is inside or outside circle
if(distance <= radius) {
  cat("(", x, ",", y, ") is in the circle")
} else {
  cat("(", x, ",", y, ") is outside the circle")
}
