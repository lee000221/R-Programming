#Create an R file named sales.r that get the price of item from the user and then display the new discount price for the item 
#based on discounts of 50%, 30% and 10%. Run the r file using terminal. 
# Get the price of the item from the user
cat("Enter the price of the item: ")
price <- readLines("stdin",1)

# Convert the input to a numeric value
price <- as.numeric(price)

# Calculate the discounted prices
discount50 <- price * 0.5
discount30 <- price * 0.7
discount10 <- price * 0.9

# Display the discounted prices
print(paste("The price of item after 50% discount is ", round(discount50, 2), "\n"))
print(paste("The price of item after 30% discount is ", round(discount30, 2), "\n"))
print(paste("The price of item after 10% discount is ", round(discount10, 2), "\n"))

