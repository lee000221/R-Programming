#lab4
#1 Write R scripts using the selection flow control for each of the following.
#a. Determine the biggest number among three numbers.
a <- 12
b <- 11
c <- 13
if (a >= b & a >= c) {
  biggest = a
  print(paste("This biggest Number is a:", biggest))
} else if (b >= a & b >= c) {
  biggest = b
  print(paste("This biggest Number is b:", biggest))
} else {
  biggest = c
  print(paste("This biggest Number is c:", biggest))
}

#b. A switch statement that displays Sunday, Monday, …, Saturday, if the number is 0, 1, ... 6.
day_number <- 1
day_name <- switch(day_number+1, "Sunday", "Monday", "Tuesday", "Wednesday","Thursday", "Friday", "Saturday")
print(day_name)
#c. Determine whether the year is a leap year. A leap year is divisible by 4 but not by 100. A leap year is also divisible by 400.
year <- 2024

if ((year %% 4 == 0 & year %% 100 != 0) | year %% 400 == 0) {
  is_leap_year <- TRUE
} else {
  is_leap_year <- FALSE
}
if (is_leap_year) {
  print(paste(year, "is a leap year."))
} else {
  print(paste(year, "is not a leap year."))
}

#2. Write R scripts using the ifelse() function for each of the following.
#a. Determine the positive and negative number in the vector.
numbers <- c(-2, 5, -7, 9)
check_positive <- ifelse(numbers > 0, "Positive", "Negative")
print(check_positive)
#b. Determine whether a character in the vector is uppercase or lowercase letter.
letters <- c("a", "B", "c", "D", "e")
upper_lower <- ifelse(letters == toupper(letters), "uppercase", "lowercase")
print(upper_lower)
#c. Compare the numbers from two vectors to determine whether a number is larger than, smaller than or equal to another number.
numbers1 <- c(3, 6, 1, 8, 4)
numbers2 <- c(2, 6, 4, 9, 3)
compared <- ifelse(numbers1 > numbers2, "larger", ifelse(numbers1 < numbers2, "smaller", "equal"))
compared
#method 2
vec1 <- c(0, 1, 2)
vec2 <- c(1, 1, 1)
judging_num <- function(vec1, vec2) {
  results<-ifelse(vec1>vec2,paste0("vec1[",seq(n),"] is larger than vec2[",seq(n),"]"),
           ifelse(vec1<vec2,paste0("vec1[",seq(n),"] is smaller than vec2[",seq(n),"]"),
                            paste0("vec1[",seq(n),"] is equal to vec2[",seq(n),"]")))
  return(results)
}

#3. Create an R file named calculator.r that stimulates a simple calculator. It reads two numbers and an operator. 
#If the operator is +, the sum is printed; if it is -, the difference is printed; 
#if it is x, the multiplication is printed; if it is /, the quotient is printed.
# See the calculator.r

#4. Create an R file named circle.r. The script will ask user to enter the radius of a circle and a coordinate point (x, y). 
#Determine whether the point is inside or outside the circle centered at (0, 0).
# See the Circle.r

#5. Write R statements using loop flow control for each of the following
#a. Find the largest integer n so that n3 is less than 2000.
n <- 1
while(n^3 < 2000) {
  n <- n + 1
}
cat("The largest integer n such that n^3 is less than 2000 is", n-1)
#b. Compute the sum of the series: 1/25+2/24+3/23 … + 25/1 in two decimal places.
sum <- 0
for(i in 1:25) {
  sum <- sum + i/(26-i)
}
cat("The sum of the series is", round(sum, 2))
#c. Display the first ten values of the Fibonacci sequence. Given the formula f1 =  1, f2 = 1, fn = fn-1 + fn-2. 
fib <- c(1, 1)
for(i in 3:10) {
  fib[i] <- fib[i-1] + fib[i-2]
}
cat("The first ten values of the Fibonacci sequence are:", paste(fib, collapse = ", "))

#6. Create an R file named score.r. 
#The script will calculate the minimum, maximum, average and standard deviation (s) of the exam score  in a subject. 
#The program will accept the score and quit if negative score is entered.
#see the score.r

#7.Create an R file named matrix.r. 
#The script will ask user to enter M and N. Create a matrix with M rows and N columns with random numbers 1-50. 
#Display the matrix and then count the number of odd and even numbers in the matrix.
#see the matrix.r
