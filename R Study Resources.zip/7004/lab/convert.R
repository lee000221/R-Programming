#Create an R file named convert.r that used to convert inch to centimeters. Given 1 inch equals to 2.54 centimeters. 
#Display the value of centimeters in two decimal places. Run the r file using terminal. Example output:
# Convert inches to centimeters
conversion_factor <- 2.54
cat("Enter the length in inches: \n")
length_in_inches <- readLines("stdin",1);

# Convert inches to centimeters
length_in_cm <- as.numeric(length_in_inches) * conversion_factor

# Print the result
cat("The length in centimeters is:", round(length_in_cm, 2), "\n")

