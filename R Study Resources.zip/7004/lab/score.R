# initialize variables
scores <- numeric()
n <- 0
sum <- 0
sum_squares <- 0

# loop to input scores
while (TRUE) {
  print(paste("Enter a score [negative score to quit]: "))
  score <- readLines("stdin",1)
  score <- as.numeric(score)
  
  # check if score is negative
  if (score < 0) {
    break
  }
  
  # add score to vector and update variables
  scores <- c(scores, score)
  n <- n + 1
  sum <- sum + score
  sum_squares <- sum_squares + score^2
}

# calculate statistics
min_score <- min(scores)
max_score <- max(scores)
avg_score <- sum/n
sd_score <- sqrt((sum_squares - (sum^2/n))/(n-1))

# print results
cat("Minimum Score:", min_score, "\n")
cat("Maximum Score:", max_score, "\n")
cat("Average Score:", round(avg_score, 1), "\n")
cat("Standard Deviation:", round(sd_score, 2), "\n")
