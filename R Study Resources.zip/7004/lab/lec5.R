#lecture 5
#Function
multiplication<-function(a=1, b=2, c=3) {
  return(a*b*c)
}
multiplication()
multiplication(2,3)
multiplication(b=4)

getInput<-function() {
  input<-readline(prompt="Enter three numbers: ")
  input<-strsplit(input, split=" ")
  return(as.numeric(unlist(input)))
}
num<-getInput()

checknumber<-function(x) {
  result<-ifelse(x>0, "Positive", ifelse(x<0, "Negative", "Zero"))
  return(result)
}
checknumber(15)
checknumber(-2)
checknumber(0)

#writeToFile
writetofile<-function(fname){
  procode<-c("SK020", "SK042", "SK013", "SK066", "SK079")
  pro<-c("Enfagrow A+", "Ayamas Nuget Crispy", "100 Plus", "Ali Cafe", "Dettol Natural")
  price<-c(36.79, 9.99, 6.49, 8.99, 4.99)
  product<-data.frame(procode, pro, as.numeric(price)) 
  names(product)<-c("ProductCode", "ProductName", "Price")
  write.table(product, fname, sep="|", row.names=F, col.names=T)
  write.csv(product, "product1.csv")
  write.csv2(product, "product2.csv")
  write.csv(product, "product3.csv", row.names=F)
  write.csv2(product, "product4.csv", row.names=F)
  saveRDS(product, "product.rds")
}
writetofile("product.txt")

#Read from File
readfromfile<-function(fname){
  df<-read.table(fname, header=T, sep="|")
  return(df)
}
df1<-readfromfile("product.txt")
df2<-read.csv("product1.csv")
df3<-read.csv2("product2.csv")
df4<-read.csv("product3.csv")
df5<-read.csv2("product4.csv")
df6<-readRDS("product.rds")

#R Session
save(list=ls(), file="week5.Rdata")
load("week5.Rdata")

#Read from Excel (.xlsx)
install.packages("xlsx")
library(xlsx)
df11 <- read.xlsx("student.xlsx", 1)
df12 <- read.xlsx("student.xlsx", 2)
df13 <- read.xlsx("student.xlsx", "ID")


