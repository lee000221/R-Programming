#1.	Create a vector named num with four elements (2, 0, 4, 6) by using R. 
num <- c(2, 0, 4, 6)
#a.	Display the third element of the vector. 
num[3]
#b.	Display the all elements of the vector except first element. 
num[-1]
#c.	Count the number of elements in the vector.
length(num)

#2.	Create a vector named q3 that add two numbers 3 and 5. After that, add 100 to this vector and display the output.
# create a vector named q3 and add two numbers 3 and 5
q3 <- c(3, 5) 
# add 100 to the vector q3
q3 <- c(q3,100) 
# display the output:
print(q3) 

#3.	Create a vector named animal that consists of cat, tiger, lion and elephant. Display the vector. 
#After that, append monkey and cow to the vector and display the output.
# Create the animal vector
animal <- c("cat", "tiger", "lion", "elephant")
# Display the vector
print(animal)
# Append "monkey" and "cow" to the vector
animal <- c(animal, "monkey", "cow")
animal <- append(animal, c("monkey", "cow"))
# Display the updated vector
print(animal)

#4.	Create two vectors named n1 and n2 of integers type (any number) and of length 3. 
#Then, add and multiply the two vectors.
n1 <- c(1L, 2L, 3L)
n2 <- c(4L, 5L, 6L)
# Addition
n_sum <- n1 + n2
print(n_sum)  
# Multiplication
n_prod <- n1 * n2
print(n_prod)  

#6.	Create a vector x of size 4 with any value from 1-10. *mean in two decimal places.
x <- sample(1:10, 4, replace = TRUE)
#a.	Display the sum, mean, minimum and the maximum of the vector x. 
print(x)
cat("Sum:", sum(x), "\n")
cat("Mean:", round(mean(x), 2), "\n")
cat("Minimum:", min(x), "\n")
cat("Maximum:", max(x), "\n")
#b.	Append 3 values (11-20) to the vector x created. Display the sum, mean, minimum and the maximum of the vector. 
x <- c(x, sample(11:20, 3, replace = TRUE))
print(x)
cat("Sum of updated x:", sum(x), "\n")
cat("Mean of updated x:", round(mean(x), 2), "\n")
cat("Minimum of updated x:", min(x), "\n")
cat("Maximum of updated x:", max(x), "\n")
#c.	Display the first two values and last two values of vector x. 
cat("First two values of x:", head(x,2), "\n")
cat("Last two values of x:", tail(x,2), "\n")
#d.	Assign the vector x in ascending order to s1, descending order to s2 and reverse order to s3. 
s1 <- sort(x)
print(s1)
s2 <- sort(x, decreasing = TRUE)
s2 <- rev(s1)
print(s2)
s3 <- rev(x)
print(s3)
#e.	Display the second highest value in vector x. 
cat("Second highest value in x:", sort(unique(x), decreasing = TRUE)[2], "\n")


